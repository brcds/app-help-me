const firebaseConfig = {
    apiKey: "AIzaSyCPgjIIjqmaMKj-rwldg3LY_KoMmaEi5_4",
    authDomain: "helpme-91ae6.firebaseapp.com",
    projectId: "helpme-91ae6",
    storageBucket: "helpme-91ae6.appspot.com",
    messagingSenderId: "655752207180",
    appId: "1:655752207180:web:9cc71b87a95763ee724de9"
  };

  export default firebaseConfig;